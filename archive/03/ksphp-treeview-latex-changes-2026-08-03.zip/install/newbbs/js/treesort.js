/*
 * treesort.js
 * 20260803 Gikoneko: ツリー表示（m=tree）のスレッド並び順トグル。
 *
 * ツリー表示画面の先頭に「並び順（新しい順／古い順）」のラジオを常時
 * 表示し、pre.msgtree ブロック（＋直後の <hr>）単位で並び順をこの
 * ブラウザ上だけで入れ替える。サーバー側には一切影響しない、完全に
 * クライアント側の個人設定機能。選んだ並び順はこのブラウザの
 * localStorage に記録し、次回以降も維持する。
 *
 * サーバーの既定描画順は「更新順（新しい順）」なので、'desc'（新しい順）
 * を既定とし、'asc'（古い順）を選んだときだけ DOM 上で反転する。
 * treehide.js とは独立（片方だけでも動作する）。
 */
(function () {
	'use strict';

	var STORAGE_KEY = 'ksphp_treesort_order';
	var DEFAULT_ORDER = 'desc'; // サーバー描画順（新しい順）

	var LANG = window.KSPHP_LANG || {};
	function L(key, fallback) {
		return (typeof LANG[key] === 'string' && LANG[key] !== '') ? LANG[key] : fallback;
	}

	function loadOrder() {
		try {
			var v = window.localStorage.getItem(STORAGE_KEY);
			return (v === 'asc' || v === 'desc') ? v : DEFAULT_ORDER;
		} catch (e) {
			return DEFAULT_ORDER;
		}
	}

	function saveOrder(order) {
		try {
			window.localStorage.setItem(STORAGE_KEY, order);
		} catch (e) { /* localStorage無効環境では記録しないだけ */ }
	}

	// pre.msgtree（＋直後の<hr>）をグループ単位で並べ替える。
	// マーカーを末尾に置き、目的の順序でその手前へ移動させることで、
	// フッターや treehide.js のパネル等、周辺要素を乱さずに反転する。
	function applyOrder(order) {
		var pres = Array.prototype.slice.call(document.querySelectorAll('pre.msgtree'));
		if (pres.length < 2) {
			return;
		}
		var parent = pres[0].parentNode;
		if (!parent) {
			return;
		}
		var groups = pres.map(function (pre) {
			var g = [pre];
			var nx = pre.nextElementSibling;
			if (nx && nx.tagName === 'HR') {
				g.push(nx);
			}
			return g;
		});
		var ordered = (order === 'asc') ? groups.slice().reverse() : groups.slice();

		var lastGroup = groups[groups.length - 1];
		var lastEl = lastGroup[lastGroup.length - 1];
		var marker = document.createComment('ksphp-treesort');
		lastEl.parentNode.insertBefore(marker, lastEl.nextSibling);
		ordered.forEach(function (g) {
			g.forEach(function (el) {
				parent.insertBefore(el, marker);
			});
		});
		if (marker.parentNode) {
			marker.parentNode.removeChild(marker);
		}
	}

	function buildControl(current) {
		var wrap = document.createElement('div');
		wrap.className = 'treesort-control';
		wrap.style.margin = '0.3em 0';
		wrap.style.fontSize = 'small';

		var label = document.createElement('span');
		label.textContent = L('TREE_SORT_LABEL', 'Sort order') + ' ';
		wrap.appendChild(label);

		var name = 'ksphp-treesort';
		[
			{ value: 'desc', text: L('TREE_SORT_NEWEST', 'Newest first') },
			{ value: 'asc', text: L('TREE_SORT_OLDEST', 'Oldest first') }
		].forEach(function (opt) {
			var id = name + '-' + opt.value;
			var radio = document.createElement('input');
			radio.type = 'radio';
			radio.name = name;
			radio.id = id;
			radio.value = opt.value;
			if (opt.value === current) {
				radio.checked = true;
			}
			radio.addEventListener('change', function () {
				if (!radio.checked) {
					return;
				}
				saveOrder(opt.value);
				applyOrder(opt.value);
			});
			var lab = document.createElement('label');
			lab.htmlFor = id;
			lab.style.marginRight = '0.8em';
			lab.appendChild(radio);
			lab.appendChild(document.createTextNode(' ' + opt.text));
			wrap.appendChild(lab);
		});
		return wrap;
	}

	document.addEventListener('DOMContentLoaded', function () {
		var pres = document.querySelectorAll('pre.msgtree');
		if (pres.length < 2) {
			return; // ツリーが1件以下なら並べ替え不要（コントロールも出さない）。
		}
		var current = loadOrder();
		var firstBlock = pres[0];
		var control = buildControl(current);
		firstBlock.parentNode.insertBefore(control, firstBlock);

		// 既定と異なる並び順が記録されていれば初期反映する。
		if (current === 'asc') {
			applyOrder('asc');
		}
	});
})();
