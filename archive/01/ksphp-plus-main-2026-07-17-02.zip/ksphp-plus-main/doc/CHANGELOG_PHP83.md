# CHANGELOG_PHP83

くずはすくりぷとPHP (ksphp-plus) の PHP 8.3 / 8.4 互換対応。
PHP8 互換のための最小修正のみ。設計・変数名・インデント・コメントは変更していません。
修正ファイルは 4 本のみ（bbs.php / sub/patTemplate.php / sub/ja/bbsadmin.php / sub/en/bbsadmin.php）。

## bbs.php
- number_format 型修正（カウンター表示 / 参加者数表示）
  - `number_format()` にエラー時の文字列が渡ると PHP8 で TypeError（Fatal）になる問題を修正。
- preg_replace `/e` 修飾子の削除対応（Func::html_decode）
  - PHP7 で削除された `/e` 修飾子を `preg_replace_callback()` へ置換。
- trim(null) Deprecated 修正（Func::fixnumberstr）

## sub/patTemplate.php
- 動的プロパティ生成 Deprecated 修正
  - クラスに `#[\AllowDynamicProperties]` を付与（PHP8.2 Deprecated / PHP9 Fatal 対策）。
- strtoupper(null) Deprecated 修正（テンプレート属性 type / placeholder / varscope の 3 箇所）

## sub/ja/bbsadmin.php ・ sub/en/bbsadmin.php
- trim(null) Deprecated 修正（フォーム値 v の 3 箇所：adminmenu / killlist / setpass）

※ 詳細な修正前後・理由・互換性・副作用は `UPDATE_HISTORY.md` を参照。
※ 今回修正しなかった既知の問題は `UPDATE_HISTORY.md` の「未修正の既知問題」章を参照。
※ ファイル権限・タイムゾーン等、PHP8互換とは別の環境要因については `UPDATE_HISTORY.md` の「運用メモ」章および `docs/permissions.md` を参照。
