# UPDATE_HISTORY (PHP 8.3 / 8.4 互換対応)

対象: くずはすくりぷとPHP (ksphp-plus)
目的: 古い PHP5 系 BBS を PHP 8.3 / 8.4 で正常動作させるための **最小限の互換修正**。
方針: リファクタリング・設計変更・コード整理・変数名/インデント/コメント変更・新規ライブラリ導入・Composer/フレームワーク化は行わない。改行コード・文字コードは維持。README は変更しない。エラー時の意味（旧バージョンの挙動）は維持する。

検証環境: PHP 8.3.30 および PHP 8.4.20（WebAssembly ビルド）で、掲示板表示 / ツリー表示 / 過去ログ検索 / パスワード設定画面の各経路を実行し、Fatal・TypeError・Warning・Deprecated が解消されていることを確認。修正は 4 ファイルのみ。他ファイルは一切変更していない。

---

## 修正一覧

### 1. bbs.php — カウンター表示の number_format 型修正

- ファイル名: `bbs.php`
- 関数名: `Bbs::setform()`（カウンター表示部）
- 修正前:
  ```php
  $counter = number_format($counter);
  ```
- 修正後:
  ```php
  if (is_numeric($counter)) { $counter = number_format((int)$counter); }
  ```
- 理由: `counter()` はカウンターファイルの書き込みに失敗した場合、数値ではなく文字列 `T('COUNTER_ERROR')` を返す。PHP8 では `number_format()` の第 1 引数が `int|float` に型厳格化されたため、文字列が渡ると致命的エラーになる。
- PHP8 で発生していたエラー内容:
  `TypeError: number_format(): Argument #1 ($num) must be of type int|float, string given`（Fatal error）
- 旧仕様との互換性: 数値のときのみ従来どおり桁区切り整形して表示。エラー文字列のときは整形せずそのまま表示する（＝カウンター異常時にエラーメッセージが表示される旧来の見え方を維持）。
- 副作用の有無: なし（正常時の出力は従来と同一。異常時は Fatal を回避してエラー文字列を表示）。

### 2. bbs.php — 参加者数表示の number_format 型修正

- ファイル名: `bbs.php`
- 関数名: `Bbs::setform()`（リアルタイム参加者数表示部）
- 修正前:
  ```php
  $mbrcount = number_format($mbrcount);
  ```
- 修正後:
  ```php
  if (is_numeric($mbrcount)) { $mbrcount = number_format((int)$mbrcount); }
  ```
- 理由: `mbrcount()` は参加者数ファイルの書き込みに失敗した場合、文字列 `T('PARTICIPANT_FILE_ERROR')` を返す。上記 1 と同様に PHP8 では TypeError になる。
- PHP8 で発生していたエラー内容:
  `TypeError: number_format(): Argument #1 ($num) must be of type int|float, string given`（Fatal error）
- 旧仕様との互換性: 数値のときのみ整形。エラー文字列はそのまま表示（旧来挙動を維持）。
- 副作用の有無: なし。

### 3. bbs.php — Func::html_decode() の preg_replace `/e` 修飾子撤廃

- ファイル名: `bbs.php`
- 関数名: `Func::html_decode()`
- 修正前:
  ```php
  $value = preg_replace("/&#([0-9]+);/me", "chr('\\1')", $value);
  ```
- 修正後:
  ```php
  $value = preg_replace_callback("/&#([0-9]+);/m", function($m){ return chr((int)$m[1]); }, $value);
  ```
- 理由: `preg_replace()` の `/e`（eval）修飾子は PHP 7.0 で削除された。PHP7 以降では置換が機能せず、警告を出して `NULL` を返すため、数値文字参照の復元が破綻する。挙動を変えずに `preg_replace_callback()` へ置換した。
- PHP8 で発生していたエラー内容:
  `Warning: preg_replace(): The /e modifier is no longer supported, use preg_replace_callback instead`（戻り値が NULL になる）
- 旧仕様との互換性: `&#NNN;` を `chr(NNN)` に復元する処理を完全に同一に維持。
- 副作用の有無: なし。なお本関数 `html_decode()` は現行コードから呼び出されていない（未使用）。将来の利用と PHP8 互換性のために合わせて是正した。

### 4. bbs.php — Func::fixnumberstr() の trim(null) 対応

- ファイル名: `bbs.php`
- 関数名: `Func::fixnumberstr()`
- 修正前:
  ```php
  $numberstr = trim($numberstr);
  ```
- 修正後:
  ```php
  $numberstr = trim($numberstr ?? '');
  ```
- 理由: 表示件数フォーム値などが未送信の場合、引数が `null` になる。PHP 8.1 以降、内部関数の非 nullable な string 引数へ `null` を渡すことは非推奨（PHP9 で TypeError 化予定）。
- PHP8 で発生していたエラー内容:
  `Deprecated: trim(): Passing null to parameter #1 ($string) of type string is deprecated`
- 旧仕様との互換性: `null → ''` として `trim('') === ''` となり、後続の `is_numeric()` 判定で FALSE となる従来挙動を維持。
- 副作用の有無: なし。

### 5. sub/patTemplate.php — 動的プロパティ生成 Deprecated 対応

- ファイル名: `sub/patTemplate.php`
- 関数名: クラス `patTemplate`（クラス全体）
- 修正前:
  ```php
  class	patTemplate
  ```
- 修正後:
  ```php
  #[\AllowDynamicProperties]
  class	patTemplate
  ```
- 理由: `patTemplate` クラスはプロパティ宣言を持たず、`$this->templates` などを実行時に動的生成している。PHP 8.2 以降、宣言のない動的プロパティ生成は非推奨（PHP9 では `Error` で致命的）。全プロパティを宣言する大改修を避け、挙動を一切変えない `#[\AllowDynamicProperties]` 属性を付与した。
- PHP8 で発生していたエラー内容:
  `Deprecated: Creation of dynamic property patTemplate::$xxx is deprecated`（$templates, $variables, $attributes 等、多数）
- 旧仕様との互換性: 属性付与のみのため挙動は不変。全プロパティを従来どおり動的に扱える。
- 副作用の有無: なし。

### 6. sub/patTemplate.php — strtoupper(null) Deprecated 対応（3 箇所）

- ファイル名: `sub/patTemplate.php`
- 関数名: テンプレート解析部（`type` / `placeholder` 属性の判定）および `patTemplate::getVars()`（`varscope` 属性の判定）
- 修正前:
  ```php
  if( $tmpl_type	=	strtoupper( $attributes['type'] ) )
  if( $placeholder = strtoupper( $attributes['placeholder'] ) )
  if( $scope = strtoupper( $this->getAttribute( $template, "varscope" ) ) )
  ```
- 修正後:
  ```php
  if( $tmpl_type	=	strtoupper( $attributes['type'] ?? '' ) )
  if( $placeholder = strtoupper( $attributes['placeholder'] ?? '' ) )
  if( $scope = strtoupper( $this->getAttribute( $template, "varscope" ) ?? '' ) )
  ```
- 理由: 該当属性が指定されていない場合、値が `null` になり `strtoupper(null)` となる。PHP 8.1 以降で非推奨（PHP9 で TypeError 化予定）。ページ描画のたびに大量に発生していた。
- PHP8 で発生していたエラー内容:
  `Deprecated: strtoupper(): Passing null to parameter #1 ($string) of type string is deprecated`
- 旧仕様との互換性: `null → ''` として `strtoupper('') === ''`（falsy）となり、既定分岐（type 無し→STANDARD、placeholder 無し→標準プレースホルダ、varscope 無し→親スコープ継承なし）へ進む従来の分岐を完全に維持。
- 副作用の有無: なし。副次的に該当箇所の "Undefined array key" 警告も解消される（出力は不変）。

### 7. sub/ja/bbsadmin.php ・ sub/en/bbsadmin.php — trim(null) Deprecated 対応（各 3 箇所）

- ファイル名: `sub/ja/bbsadmin.php`、`sub/en/bbsadmin.php`
- 関数名: `Bbsadmin`（`adminmenu` 表示 / `killlist` 表示 / `prtsetpass()` の 3 箇所）
- 修正前:
  ```php
  $this->t->addVar('adminmenu', 'V', trim($this->f['v']));
  $this->t->addVar('killlist', 'V', trim($this->f['v']));
  $this->t->addVar('setpass', 'V', trim($this->f['v']));
  ```
- 修正後:
  ```php
  $this->t->addVar('adminmenu', 'V', trim($this->f['v'] ?? ''));
  $this->t->addVar('killlist', 'V', trim($this->f['v'] ?? ''));
  $this->t->addVar('setpass', 'V', trim($this->f['v'] ?? ''));
  ```
- 理由: フォーム値 `v` が未送信のとき `null` になり `trim(null)` となる。とくに `prtsetpass()` は管理パスワード未設定（初回設置）時に毎回実行される経路であり発生頻度が高い。
- PHP8 で発生していたエラー内容:
  `Deprecated: trim(): Passing null to parameter #1 ($string) of type string is deprecated`
- 旧仕様との互換性: `null → ''` として `trim('') === ''` を維持。表示は不変。
- 副作用の有無: なし。日本語版 (`ja`) と英語版 (`en`) の両方に同一修正を適用（`TEMPLATE_LANGUAGE` の設定に依らず両言語で互換）。

---

## 未修正の既知問題

今回のポリシー（PHP8 で正常動作させるための最小修正、歴史的ソフトウェアの原状保存）に基づき、以下は **意図的に未修正** としています。今後 PHP を更に新しくする際の検討材料として記録します。

1. **同梱オリジナル patTemplate ライブラリ (`sub/patTemplate/` 配下)**
   `sub/patTemplate/include/patTemplate.php` および `sub/patTemplate/example*.php` は、PHP8 で削除された `each()`、PHP7 で削除された `eregi()`（POSIX 正規表現）を含み、そのまま実行すると Fatal error になります。ただし本 BBS が実際に使用しているのは `sub/patTemplate.php`（今回修正済み）であり、これら同梱ファイルは掲示板の実行経路に含まれません。歴史的資料・配布物として原状保存するため未修正としています。これらを直接利用する場合は `each()`→`foreach`、`eregi()`→`preg_match` 等への改修が別途必要です。

2. **画像掲示板モジュール (`sub/*/bbsimage.php`)**
   既定設定は `BBSMODE_IMAGE = 0`（無効）であり、通常運用では実行されません。そのため今回のランタイム実機検証の対象外です。有効化した場合、`getimagesize()` 失敗時の `$imageinfo[0]` 参照や `str_pad(null,...)` 等に起因する null 由来 Deprecated が残存する可能性があります。画像機能を使用する場合は個別確認を推奨します。

3. **`error_reporting` と `@` 演算子による抑制に依存している箇所**
   本スクリプトは `bbs.php` 冒頭で `error_reporting(E_ERROR | E_WARNING | E_PARSE)` を設定し、さらに独自の `set_error_handler` で「Undefined array key」警告をノーティスへ降格しています。加えて随所で `@` 演算子による抑制が使われています（例: `@explode(',', $logdata[0], 3)` 等）。これらにより E_DEPRECATED / E_NOTICE / 未定義キー警告は既に画面へ出力されません。今回はこの既存方針を尊重し、`@` で抑制済みの null 由来 Deprecated は変更していません。ただし **PHP 9 では `null` 渡しが TypeError 化する予定** のため、抑制に依存している箇所は将来的に個別対応が必要になります。

4. **投稿(POST) / 管理ログイン後 / UNDO の各処理**
   これらは `crypt()`・セッション・プロテクトコード（pcode）検証を伴うため、今回のランタイム検証は限定的（主に静的解析）です。既存の `@` 抑制と本修正により主要な Fatal / TypeError は解消済みですが、特殊入力時に未検出の Deprecated が残る可能性があります。

5. **ユーザー入力・設定値を正規表現パターンに用いる箇所**
   `hostname_match()` の `"/$hostpattern/"` などは設定/入力に依存します。多くは条件分岐や `@` で保護されていますが、PHP9 対応時には null 渡しの有無を個別確認することを推奨します。

6. **`sub/patTemplate.php` のプロパティ宣言**
   本修正では `#[\AllowDynamicProperties]` 属性で動的プロパティ生成の非推奨を回避しています（挙動不変・最小修正）。より将来に堅牢にするには、全プロパティの明示的な宣言化が望ましいですが、これは設計変更に相当するため今回は見送りました。

---

## 運用メモ（PHP8互換とは別問題）

実機検証中に発生したエラーの一部は、PHP8互換性ではなく、Apache実行ユーザー（`www-data`）のファイル/ディレクトリ権限不足、および PHP のタイムゾーン未設定が原因だった。コード修正は行っていない。

確認した事例:

- `bbs.cnt`: `664` → `666` で「参加者ファイル出力エラー」が解消。
- `log/`: Apache が過去ログファイルを新規作成できる権限（グループ `www-data` への書き込み権限）が必要。
- `date.timezone`: 初期状態では `UTC` のままで投稿時刻が9時間ずれていた。Apache用 `php.ini` に `date.timezone = Asia/Tokyo` を設定し再起動することで解消。

原因の切り分け方・対応コマンドの詳細は `docs/permissions.md` を参照。

この区別（コードの問題かサーバー設定の問題か）を残しておくことで、次に環境を構築する人や、将来 PHP 8.5 / 9.0 へ移行する際の判断がしやすくなる。
